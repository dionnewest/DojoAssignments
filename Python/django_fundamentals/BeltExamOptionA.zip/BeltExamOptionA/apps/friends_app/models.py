from __future__ import unicode_literals
from ..login_reg.models import *

from django.db import models

class FriendManager(models.Manager):
	def add_friend(req, friend_id, user_id):
		current_user = User.manager.get(id=user_id)
		other_user = User.manager.get(id=friend_id)
		new_friend = User.friend.add(other_user)
		return new_friend

class Friend(models.Model):
	user = models.ForeignKey(User, related_name="friend")
	friend = models.ForeignKey(User, related_name="user")
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	manager = FriendManager()
	# manager = UserManager()
	def __repr__(self):
		return "Relationship #{}: User id is: {}, Friend id is {}".format(self.id, self.user, self.friend)

