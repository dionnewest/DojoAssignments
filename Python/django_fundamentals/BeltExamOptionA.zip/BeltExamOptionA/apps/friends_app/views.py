from django.shortcuts import render
from .models import *


# Create your views here.

def index(req):
	# User.manager.all().delete()
	return render(req, 'login_reg/index.html')

def user(req, user_id):
	user = User.manager.get(id=user_id)
	content = {
		'user_alias':user.alias,
		'user_name':user.name,
		'user_email':user.email
	}
	return render(req, 'friends_app/user.html', content)

def add_friend(req, friend_id):
	new_friend = User.manager.add_friend(req.session['user_id'], friend_id)
	return redirect ('/success')