#OPTION A

from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^$', views.index),
	url(r'^/(?P<user_id>\d+)$', views.user),
	url(r'^add_friend/(?P<friend_id>\d+)$', views.add_friend)
]
	# url(r'^users', views.users)
