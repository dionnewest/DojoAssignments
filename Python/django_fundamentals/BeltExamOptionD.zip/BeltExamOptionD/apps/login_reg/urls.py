#OPTION A

from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^main$', views.index),
	url(r'^logout$', views.logout),
	url(r'^/', views.index2),
	url(r'^register$', views.register),
	url(r'^login$', views.login),
	url(r'^success$', views.success),
	url(r'^new_quote', views.new_quote),
	url(r'^users/(?P<user_id>\d+)$', views.users),
	url(r'^add_favorite/(?P<user_id>\d+)/(?P<quote_id>\d+)$', views.add_favorite),
	url(r'^remove_favorite/(?P<user_id>\d+)/(?P<quote_id>\d+)$', views.remove_favorite),
	url(r'^\w+', views.success_other)
]
	# url(r'^users', views.users)
