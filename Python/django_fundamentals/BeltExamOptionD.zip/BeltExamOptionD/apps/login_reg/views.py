#OPTION A
from django.shortcuts import render, HttpResponse, redirect
from .models import *

# Create your views here.

def index(req):
	# User.manager.all().delete()
	return render(req, 'login_reg/index.html')

def logout(req):
	req.session.flush()
	return redirect('/main')

def index2(req):
	# User.manager.all().delete()
	return redirect('/main')

def success_other(req):
	return redirect('/success')

def register(req):
	valid = User.manager.registration_validator(req.POST)
	if valid[0] == False:
		for key, message in valid[1].iteritems():
			messages.error(req, message)
		return redirect('/')
	else:
		req.session['user_name'] = valid[2]
		req.session['user_id'] = valid[3]
		req.session['message'] = "You have successfully registered!"
		return redirect('/success')

def login(req):
	valid = User.manager.login_validator(req.POST)
	if valid[0] == False:
		for key, message in valid[1].iteritems():
			messages.error(req, message)
		return redirect('/')
	else:
		req.session['user_name'] = valid[1]
		req.session['user_id'] = valid[2]
		req.session['message'] = "You have successfully logged in!"
		return redirect('/success')

def success(req):
	if 'user_id' not in req.session:
		return redirect ('/main')
	# all_quotes = Quote.manager.all().delete()
	all_quotes = Quote.manager.all()
	user = User.manager.get(id=req.session['user_id'])
	favorite_quotes = user.favorite.all()
	quotable_quotes = set(all_quotes) - set(favorite_quotes)
	content = {
		'user_name':req.session['user_name'],
		'all_quotes':all_quotes,
		'user_id':req.session['user_id'],
		'favorite_quotes':favorite_quotes,
		'quotable_quotes':quotable_quotes
	}
	return render(req, 'login_reg/success.html', content)

def users(req, user_id):
	count = 0
	if 'user_id' not in req.session:
		return redirect ('/main')
	all_quotes = Quote.manager.filter(user_id=user_id)
	for quotes in all_quotes:
		count += 1
	quoter_alias = User.manager.get(id=user_id).alias
	quoter_name = User.manager.get(id=user_id).name
	content = {
		'quoter_name':quoter_name,
		'quoter_alias':quoter_alias,
		'all_quotes':all_quotes,
		'count':count,
		'user_id':req.session['user_id'],
	}
	return render(req, 'login_reg/user.html', content)

def new_quote(req):
	quote_info=Quote.manager.new_quote(req.POST)
	if quote_info[0] == False:
		for key, message in quote_info[1].iteritems():
			messages.error(req, message)
		return redirect('/success')
	quoted_by = quote_info[1]
	quote_message = quote_info[2]
	Quote.manager.create(quoted_by=quoted_by, message=quote_message, user_id=req.session['user_id'])
	return redirect('/success')

def add_favorite(req, user_id, quote_id):
	user = User.manager.get(id=user_id)
	quote = Quote.manager.get(id=quote_id)
	quote.favorites.add(user)
	return redirect('/success')

def remove_favorite(req, user_id, quote_id):
	user = User.manager.get(id=user_id)
	quote = Quote.manager.get(id=quote_id)
	quote.favorites.remove(user)
	return redirect('/success')


