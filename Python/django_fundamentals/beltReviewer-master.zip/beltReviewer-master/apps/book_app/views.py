from django.shortcuts import render

# Create your views here.
def index(req):
    return render(req,'book_app/index.html')
def addBook(req):
    return render(req,'book_app/create_book.html')
def createBook(req):
    return redirect('books/{}'.format(id))
def show(req,id):
    
    return render(req,'book_app/details.html')
